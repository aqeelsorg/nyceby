		</div>
	</div>
	<div id="footer">
		<div id="footer_top">
		
		</div>
		<div id="footer_bot">
			<div id="copyright">FUEL CMS is a product by <a href="http://www.thedaylightstudio.com" target="_blank">Daylight Studio</a>. <br />Copyright &copy; <?php echo date('Y')?> Daylight Studio,  All Rights Reserved.</div>
		</div>
	</div>
</div>

</body>
</html>